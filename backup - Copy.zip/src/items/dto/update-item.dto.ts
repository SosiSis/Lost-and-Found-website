export class updateItemDto {
  // name?: string;
  description?: string;

}
