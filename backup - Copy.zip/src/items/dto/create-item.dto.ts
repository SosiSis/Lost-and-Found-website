export class createItemDto{
  readonly description: string
  readonly picture: Buffer
  readonly category:string
  
}