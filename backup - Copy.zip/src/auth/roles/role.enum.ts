//role.enum.ts
export enum Role {
  User = 'user',
  Admin = 'admin'
}